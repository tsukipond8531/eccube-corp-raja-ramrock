<?php

declare(strict_types=1);

namespace Customize\Form\Extension\Shopping;

use Eccube\Common\EccubeConfig;
use Eccube\Form\Type\Shopping\OrderType;
use Symfony\Component\Form\AbstractTypeExtension;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Validator\Constraints as Assert;

class OrderTypeExtension extends AbstractTypeExtension
{
    /**
     * @var EccubeConfig
     */
    protected $eccubeConfig;

    /**
     * OrderType constructor.
     *
     * @param EccubeConfig $eccubeConfig
     */
    public function __construct(
      EccubeConfig $eccubeConfig
    ) {
        $this->eccubeConfig = $eccubeConfig;
    }

    public function getExtendedType(): string
    {
        return OrderType::class;
    }

    public function getExtendedTypes(): iterable
    {
        return [OrderType::class];
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
      $builder
        ->add('watch_target', ChoiceType::class, [
            'required' => true,
            'choices' => [
                '見守り対象者がいます' => '見守り対象者がいます',
                '見守り対象者がいません' => '見守り対象者がいません',
            ],
            'expanded' => true,
            'multiple' => false,
            'mapped' => false,
            'constraints' => [
                new Assert\NotBlank(),
            ],
        ]);
    }
}