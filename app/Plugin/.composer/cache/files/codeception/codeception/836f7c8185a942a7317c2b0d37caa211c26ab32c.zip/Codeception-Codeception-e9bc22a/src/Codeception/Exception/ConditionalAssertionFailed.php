<?php
namespace Codeception\Exception;

class ConditionalAssertionFailed extends \PHPUnit\Framework\AssertionFailedError
{
}
