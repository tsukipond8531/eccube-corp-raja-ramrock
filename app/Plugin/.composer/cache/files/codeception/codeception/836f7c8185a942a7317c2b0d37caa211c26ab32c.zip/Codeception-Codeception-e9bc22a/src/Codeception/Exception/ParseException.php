<?php
namespace Codeception\Exception;

class ParseException extends \Exception
{
}
