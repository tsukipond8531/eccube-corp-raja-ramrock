const build = require('./gulp/build/build')
const start = require('./gulp/build/start')

exports.default = build
exports.start = start
